# Disease-Prediction
Implementation of KNNs, Naive Bayes, Decision Trees and Random Forests to predict diseases according to the symptoms entered by the user
